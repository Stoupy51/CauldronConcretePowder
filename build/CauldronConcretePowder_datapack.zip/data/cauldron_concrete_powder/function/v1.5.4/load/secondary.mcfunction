
#> cauldron_concrete_powder:v1.5.4/load/secondary
#
# @within	cauldron_concrete_powder:v1.5.4/load/main
#

# Cauldron Concrete Powder
scoreboard objectives add cauldron_concrete_powder.data dummy
tag Stoupy51 add convention.debug

# Confirm load
function cauldron_concrete_powder:v1.5.4/load/confirm_load

